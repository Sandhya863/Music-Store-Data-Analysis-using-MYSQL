create database music_st;
use music_st;
select * from artist;
select * from album ;
select * from employee;
select * from genre;
select * from customer;
select * from invoice;
select * from invoice_line;
select * from media_type;
select * from playlist;
select * from playlist_track;
select * from track;
-- 1.Who is the senior most employee based on job title? 
select * from employee
order by levels desc
limit 1;
-- 2.Which countries have the most Invoices?
SELECT billing_country,COUNT(*) AS invoice_count
FROM Invoice
GROUP BY billing_country
ORDER BY invoice_count DESC;
-- 3. What are the top 3 values of total invoice?
SELECT invoice_id,total
FROM Invoice
ORDER BY total DESC
LIMIT 3;
-- 4. Which city has the best customers?
SELECT billing_city,SUM(total) AS total_revenue
FROM Invoice
GROUP BY billing_city
ORDER BY total_revenue DESC
LIMIT 1;
-- 5. Who is the best customer? 
SELECT c.customer_id,c.first_name,c.last_name,
SUM(i.total) AS total_spent
FROM Customer c
JOIN Invoice i ON c.customer_id = i.customer_id
GROUP BY c.customer_id,c.first_name,c.last_name
ORDER BY total_spent DESC
LIMIT 2;
-- 6. Write a query to return the email, first name, last name, & Genre of all Rock Music listeners. 
-- Return your list ordered alphabetically by email starting with A
select distinct c.email,c.first_name,c.last_name,g.name
from customer c
join invoice i
on c.customer_id=i.customer_id
join invoice_line l
on i.invoice_id=l.invoice_id
join track t
on l.track_id=t.track_id
join genre g
on g.genre_id=t.genre_id
where g.name='Rock'
and c.email like 'A%'
order by c.email asc;
-- 7. Let's invite the artists who have written the most rock music in our dataset.
-- Write a query that returns the Artist name and total track count of the top 10 rock bands 
SELECT a.artist_id,a.name AS artist_name,COUNT(t.track_id) AS rock_track_count
FROM Artist a
JOIN Album al 
ON a.artist_id = al.artist_id
JOIN Track t 
ON al.album_id = t.album_id
JOIN Genre g 
ON t.genre_id = g.genre_id
WHERE g.name = 'Rock'
GROUP BY a.artist_id,a.name
ORDER BY rock_track_count DESC
LIMIT 10;
-- 8. Return all the track names that have a song length longer than the average song length.
-- Return the Name and Milliseconds for each track. Order by the song length, with the longest songs listed first.
SELECT name,milliseconds
FROM Track
WHERE milliseconds > (SELECT AVG(milliseconds) FROM Track)
ORDER BY milliseconds DESC
Limit 10;
-- 9. Find how much amount is spent by each customer on artists? 
-- Write a query to return customer name, artist name and total spent 
Select c.first_name,c.last_name,ar.name,sum(il.unit_price*il.quantity)as money_spent
from customer as c
join invoice as i
on c.customer_id=i.customer_id
join invoice_line as il
on i.invoice_id=il.invoice_id
join track as t
on il.track_id=t.track_id
join album as al
on t.album_id=al.album_id
join artist as ar
on al.artist_id=ar.artist_id
group by ar.artist_id,c.customer_id,c.first_name,c.last_name,ar.name;


-- 10. We want to find out the most popular music Genre for each country. 
-- We determine the most popular genre as the genre with the highest amount of purchases. 
-- Write a query that returns each country along with the top Genre. 
-- For countries where the maximum number of purchases is shared, return all Genres
select g.name,c.country,count(il.quantity) as highest_purchases
from customer as c
join invoice as i
on c.customer_id=i.customer_id
join invoice_line as il
on i.invoice_id=il.invoice_id
join track as t
on il.track_id=t.track_id
join genre as g
on t.genre_id=g.genre_id
group by g.genre_id,g.name,c.country
order by highest_purchases desc;

-- 11. Write a query that determines the customer that has spent the most on music for each country. 
-- Write a query that returns the country along with the top customer and how much they spent.
 -- For countries where the top amount spent is shared, provide all customers who spent this amount
 Select c.country,c.first_name,c.last_name,sum(il.unit_price*il.quantity)as money_spent
 from customer as c
join invoice as i
on c.customer_id=i.customer_id
join invoice_line as il
on i.invoice_id=il.invoice_id
group by c.customer_id,c.first_name,c.last_name,c.country
having sum(il.unit_price * il.quantity) = (
     select max(total_spent)
     from (
           select sum(il2.unit_price * il2.quantity) as total_spent
		   from customer as c2
           join invoice as i2 on c2.customer_id = i2.customer_id
           join invoice_line as il2 on i2.invoice_id = il2.invoice_id
           where c2.country = c.country
		   group by c2.customer_id,c2.first_name,c2.last_name,c2.country
    ) as country_totals
) 
order by c.country;


















